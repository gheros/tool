#!/bin/bash
# attach the mainnet with default moac ipc
echo "Make sure the moac is running!"
./moac attach /home/ubuntu/.moac/moac.ipc
